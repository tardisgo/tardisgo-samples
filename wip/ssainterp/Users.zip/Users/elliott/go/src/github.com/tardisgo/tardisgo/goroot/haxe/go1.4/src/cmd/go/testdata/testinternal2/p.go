package p

import _ "./x/y/z/internal/w"
