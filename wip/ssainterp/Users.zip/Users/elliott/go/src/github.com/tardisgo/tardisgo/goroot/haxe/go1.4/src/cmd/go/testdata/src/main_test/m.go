package main

func F()    {}
func main() {}
