package badsyntax

func func func func func!
