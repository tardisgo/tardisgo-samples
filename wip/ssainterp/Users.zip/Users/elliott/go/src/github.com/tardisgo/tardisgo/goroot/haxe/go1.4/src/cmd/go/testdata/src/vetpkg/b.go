package p

import "fmt"

func f() {
	fmt.Printf("%d")
}
