package p

func F() int { return 1 }
