package badvar_test

func f() {
	_ = notdefined
}
