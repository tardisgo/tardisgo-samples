package main

import "./sub"

func main() {
	sub.Hello()
}
