package notest

func hello() {
	println("hello world")
}
Hello world
