package xtestonly

func F() int { return 42 }
